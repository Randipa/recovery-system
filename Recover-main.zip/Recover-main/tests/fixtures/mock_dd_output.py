MOCK_DD_OUTPUT = "Lorem ipsum dolor sit amet".encode("utf8")
